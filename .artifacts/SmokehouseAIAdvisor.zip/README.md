# SmokehouseAIAdvisor

- **Runtime:** `python3.13`
- **Handler:** `lambda_function.lambda_handler`
- **Note:** Environment variables are *not* exported. Configure via AWS Console/SSM/Secrets.
- **Deploy:** (to be added later via CI/CD)

